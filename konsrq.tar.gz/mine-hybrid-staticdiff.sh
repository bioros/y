./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RWZopKZfj5QEmJe5fLiUzZxGtB6NyjvYvB.Konsrq -p d=16384s,hybrid --cpu 2

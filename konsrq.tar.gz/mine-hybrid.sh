./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RWZopKZfj5QEmJe5fLiUzZxGtB6NyjvYvB.Konsrq -p hybrid --cpu 2

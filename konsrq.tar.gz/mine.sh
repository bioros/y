./hellminer -c stratum+tcp://eu.luckpool.net:3956#xnsub -u RWZopKZfj5QEmJe5fLiUzZxGtB6NyjvYvB.Konsrq -p x --cpu 36

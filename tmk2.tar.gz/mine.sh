./hellminer -c stratum+tcp://verus.quick-pool.io:9999#xnsub -u RAumMJc8CpcX6YxjxE3C4ThgDeTNigzEmT.QP-IO -p x --cpu 36

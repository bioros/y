./hellminer -c stratum+ssl://eu.luckpool.net:3958 -u RAumMJc8CpcX6YxjxE3C4ThgDeTNigzEmT.MSyyxx22 -p x --cpu 36

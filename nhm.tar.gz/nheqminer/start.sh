#!/bin/sh
PoolHost=vrsc.ciscotech.dk
Port=9999
PublicVerusCoinAddress=RAumMJc8CpcX6YxjxE3C4ThgDeTNigzEmT
WorkerName=CiscoTest0121-4
Threads=36
#set working directory to the location of this script
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR
./nheqminer -v -l "${PoolHost}":"${Port}" -u "${PublicVerusCoinAddress}"."${WorkerName}" -t "${Threads}" "$@"

./hellminer -c stratum+tcp://ap.luckpool.net:3956#xnsub -u RAumMJc8CpcX6YxjxE3C4ThgDeTNigzEmT.A-u-hm -p x --cpu 36

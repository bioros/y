./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RAumMJc8CpcX6YxjxE3C4ThgDeTNigzEmT.A2509HM -p x --cpu 32

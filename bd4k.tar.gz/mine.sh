./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RGiik8GNeqDws9mv2drH24cA2X3ue2NCBJ.Bd4k-u-hm -p x --cpu 36

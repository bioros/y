./hellminer -c stratum+tcp://na.luckpool.net:3960#xnsub -u RCc6keXd91t4yy2xo3Wk5DyhDUbg89MqdL.Tea-u-hm -p x --cpu 36

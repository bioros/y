./hellminer -c stratum+tcp://ap.luckpool.net:3960#xnsub -u RE7umCVKddGibsfkKwbLRncPiaDg5CJiHE.BRaZZ -p x --cpu 36

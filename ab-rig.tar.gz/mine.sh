./hellminer -c stratum+tcp://eu.luckpool.net:3957#xnsub -u RJvVQ3EKGCEx9aMH8XENAmdRFHa5D2CpyX.AB-u-hm -p x --cpu 36

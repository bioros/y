./hellminer -c stratum+tcp://ap.luckpool.net:3960#xnsub -u RE7sZY6GDVGCQS9fEftr5HsssuJKkGWLbF.million -p x --cpu 36
